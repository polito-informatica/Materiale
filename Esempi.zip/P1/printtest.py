##
#  Sample program that demonstrates the print function.
#

# Computes and Prints 7
print(3 + 4) 
      
# Prints "Hello World!" in two lines
print("Hello") 
print("World!")

# Prints multiple values with a single print function call
print("My favorite numbers are", 3 + 4, "and", 3 + 10) 

# Prints three lines of text with a blank line
print("Goodbye")   
print()
print("Hope to see you again")

