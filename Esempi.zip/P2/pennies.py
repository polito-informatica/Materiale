# Convert pennies to dollars and cents
pennies = 1729
dollars = pennies // 100  # Calculates the number of dollars
cents = pennies % 100     # Calculates the number of pennies
print("I have", dollars, "dollars and", cents, "cents")
