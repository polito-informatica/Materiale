# Constants

BOTTLE_VOLUME = 0.75
CAN_VOLUME = 0.33

# Input data

bottles = 4
cans = 6

# Computation

total = 0

total = bottles * BOTTLE_VOLUME

total = total + cans * CAN_VOLUME

print(total)